package com.example.stopwatchapp;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timerText;
    private Button startButton, pauseButton, resetButton;

    private Handler handler = new Handler();
    private long startTime = 0;
    private boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerText = findViewById(R.id.timerText);
        startButton = findViewById(R.id.startButton);
        pauseButton = findViewById(R.id.pauseButton);
        resetButton = findViewById(R.id.resetButton);

        startButton.setOnClickListener(v -> startTimer());
        pauseButton.setOnClickListener(v -> pauseTimer());
        resetButton.setOnClickListener(v -> resetTimer());
    }

    private void startTimer() {
        if (!isRunning) {
            isRunning = true;
            startTime = System.currentTimeMillis();
            handler.post(updateTimer);
        }
    }

    private void pauseTimer() {
        if (isRunning) {
            isRunning = false;
            handler.removeCallbacks(updateTimer);
        }
    }

    private void resetTimer() {
        isRunning = false;
        handler.removeCallbacks(updateTimer);
        timerText.setText("00:00:000");
    }

    private final Runnable updateTimer = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                long elapsed = System.currentTimeMillis() - startTime;
                int minutes = (int) (elapsed / 1000) / 60;
                int seconds = (int) (elapsed / 1000) % 60;
                int milliseconds = (int) (elapsed % 1000);

                timerText.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));
                handler.postDelayed(this, 10);
            }
        }
    };
}